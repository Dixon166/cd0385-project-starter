# Report: Predict Bike Sharing Demand with AutoGluon Solution
#### Pierre Siccardi

## Initial Training
### What did you realize when you tried to submit your predictions? What changes were needed to the output of the predictor to submit your results?
All the predictions needed to be equal or greater to zero for submission. So every negative values had to be changed to zero.

### What was the top ranked model that performed?
Weighted Ensemble achieved the best performance.

## Exploratory data analysis and feature creation
### What did the exploratory analysis find and how did you add additional features?
Datetime were not well considered by Autogluon. Hence the solution was to split datetime as separate features. By using to_datetime function, it has been easy to crate and add to the dataframe unique columns for day, month and hour.

### How much better did your model preform after adding additional features and why do you think that is?
Thanks to the split mentionned before, error has been divided  by more than two. Its means hours and days play a key role in bike sharing predictions.

## Hyper parameter tuning
### How much better did your model preform after trying different hyper parameters?
It unfortunately did not achieved better results.

### If you were given more time with this dataset, where do you think you would spend more time?
I think I would go more in details in each model hyperparameters (i.e. catboost or xgboost hyperparameters). Another idea would be to keep only few models to train in Autogluon to not loose time on less capable model for this task.

### Create a table with the models you ran, the hyperparameters modified, and the kaggle score.
|model|hpo1|hpo2|hpo3|score|
|--|--|--|--|--|
|initial|time_limit=600|presets=best_quality|/|1.39|
|add_features|time_limit=600|presets=best_quality|/|0.55|
|hpo|time_limit=600|presets=best_quality|auto_stack=True,hyperparameter_tune_kwargs=num_trials: num_trials,scheduler:local,searcher:search_strategy|0.56|

### Create a line plot showing the top model score for the three (or more) training runs during the project.

![model_train_score.png](model_train_score.png)

### Create a line plot showing the top kaggle score for the three (or more) prediction submissions during the project.

![model_test_score.png](model_test_score.png)

## Summary
This project has been a good introduction to the capabilities of Autogluon. Thanks to this framework, it is easy to get a rapid overview on a multitude of model performances for a specific task. It then takes more time to fine-tune the hyperparameter to achieve better results.

Note for the reviewer: To my perspective, this projects sometimes lack of guidance. For example, for the hyperparameter section, there is only three bullet point which are not really understandable (it looks like some words are missing...). Having more details about what is expected from the candidate would help a lot. Thank you.